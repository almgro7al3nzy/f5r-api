module.exports = {

	// the database url to connect
	url : 'mongodb://localhost/node-todo'
}
